/* *****************************************************************************
 *  Name:              Dakota Styck
 *  Last modified:     June 29, 2023
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;

public class HelloGoodbye {
    public static void main(String[] args) {

        // Handle invalid arguments
        if (args.length != 2) {
            StdOut.print("Exactly 2 arguments are needed.");
            StdOut.print("Ex: \"java HelloGoodbye Kevin Bob\"");
        }

        // Get Names
        String name1 = args[0];
        String name2 = args[1];

        // Output
        StdOut.println("Hello " + name1 + " and " + name2 + '.');
        StdOut.println("Goodbye " + name2 + " and " + name1 + '.');
    }
}
