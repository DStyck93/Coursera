/* *****************************************************************************
 *  Name:              Dakota Styck
 *  Last modified:     June 30, 2023
 **************************************************************************** */

import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class RandomWord {
    public static void main(String[] args) {

        String input;
        String champion = "";
        double probability;
        boolean isChampion;

        // Handle invalid input
        if (StdIn.isEmpty()) {
            StdOut.println("No input detected. Please try again.");
            return;
        }

        // Get the champion
        int i = 1;
        while (!StdIn.isEmpty()) {
            input = StdIn.readString();
            probability = 1.0 / i;
            isChampion = StdRandom.bernoulli(probability);
            if (isChampion) champion = input;
            i++;
        }

        // Output
        StdOut.println(champion);
    }
}
