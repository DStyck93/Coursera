import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

    private WeightedQuickUnionUF uf;
    private boolean[][] isOpen;
    private int width;
    private int ufSize;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {

        // Handle exceptions
        if (n <= 0) throw new IllegalArgumentException("n: " + n);

        // Save width of grid
        width = n;

        // Initialize nodes to closed
        isOpen = new boolean[n + 1][n + 1];

        // Create WeightedQuickUnionUF object
        ufSize = n * n + 2; // percolation grid + 1 top node & 1 bottom node
        uf = new WeightedQuickUnionUF(ufSize);

        // Connect top/bottom nodes to the grid
        for (int i = 1; i <= width; i++) {
            uf.union(0, i);
            uf.union(ufSize - 1, ufSize - 1 - i);
        }
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        testRange(row, col);

        // open the node
        isOpen[row][col] = true;

        // Connect to adjacent nodes that are also open
        connectToAdjOpen(row, col);
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        testRange(row, col);
        return isOpen[row][col];
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        testRange(row, col);
        return uf.find(0) == uf.find(getIndex(row, col));
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        int numOpen = 0;
        for (int row = 1; row <= width; row++) {
            for (int col = 1; col <= width; col++) {
                if (isOpen(row, col)) numOpen++;
            }
        }
        return numOpen;
    }

    // does the system percolate?
    public boolean percolates() {
        if (width == 1 && !isOpen(1, 1)) return false;
        return uf.find(0) == uf.find(ufSize - 1);
    }

    // Throws IllegalArgumentException if an argument is outside its prescribed range
    private void testRange(int row, int col) {
        if (row > width || row <= 0 || col > width || col <= 0) {
            throw new IllegalArgumentException("\nrow: " + row + "\ncol: " + col);
        }
    }

    // Converts the given grid position of the Percolation to the index number in the WeightedQuickUnionUF object
    private int getIndex(int row, int col) {
        return (row - 1) * width + col;
    }

    // Connects the current (open) node to other adjacent nodes that are also open;
    private void connectToAdjOpen(int row, int col) {

        int index = getIndex(row, col);

        // Connect to node above?
        if (row > 1) {
            if (isOpen(row - 1, col)) {
                uf.union(index, index - width);
            }
        }

        // Connect to node below?
        if (row < width) {
            if (isOpen(row + 1, col)) {
                uf.union(index, index + width);
            }
        }

        // Connect to left node?
        if (col > 1) {
            if (isOpen(row, col - 1)) {
                uf.union(index, index - 1);
            }
        }

        // Connect to right node?
        if (col < width) {
            if (isOpen(row, col + 1)) {
                uf.union(index, index + 1);
            }
        }
    }

    // test client
    public static void main(String[] args) {
    }
}
