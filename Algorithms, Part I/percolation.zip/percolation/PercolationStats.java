import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {

    private double mean;
    private double stddev;
    private double confidenceLo;
    private double confidenceHi;

    // perform independent trials on an n-by-n grid fixme
    public PercolationStats(int n, int trials) {

        // Handle exceptions
        if (n <= 0 || trials <= 0) throw new IllegalArgumentException("n: " + n + "\ntrials: " + trials);

        double[] percThresholds = new double[trials];

        // Repeat T times (based on trials input)
        for (int t = 0; t < trials; t++) {

            // Initialize all sites to be blocked
            Percolation perc = new Percolation(n);
            int[] blockedSites = new int[n * n];
            for (int i = 0; i < blockedSites.length; i++) blockedSites[i] = i + 1;

            // Uniformly randomize blocked sites
            StdRandom.shuffle(blockedSites);

            // Repeat the following until the system percolates
            int i = 0;
            while (!perc.percolates()) {

                // Choose a site uniformly at random among all blocked sites.
                int site = blockedSites[i];
                int[] gridLocation = getGridLocation(site, n);
                int row = gridLocation[0];
                int col = gridLocation[1];

                // Open the site
                perc.open(row, col);

                i++; // Next site
            }

            // The fraction of sites that are opened when the system percolates
            // provides an estimate of the percolation threshold
            double fractionOpen = (double) i / (n * n);
            percThresholds[t] = fractionOpen;
        }

        // Get mean
        mean = StdStats.mean(percThresholds);

        // Get stddev
        stddev = StdStats.stddev(percThresholds);

        // get lo
        double confidence95 = 1.96;
        confidenceLo = mean - confidence95 * stddev / Math.sqrt(trials);

        // get hi
        confidenceHi = mean + confidence95 * stddev / Math.sqrt(trials);
    }

    private int[] getGridLocation(int site, int width) {

        int row = (int) Math.ceil((double) site / (double) width);
        int col = 0;
        if (site % width == 0) col = width;
        else col = site % width;
        return new int[]{row, col};
    }

    // sample mean of percolation threshold
    public double mean() {
        return mean;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return stddev;
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return confidenceLo;
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return confidenceHi;
    }

    // test client
    public static void main(String[] args) {

        // Get inputs
        int n = Integer.parseInt(args[0]);
        int trials = Integer.parseInt(args[1]);

        // Create Percolation Stats object
        PercolationStats ps = new PercolationStats(n, trials);

        // Output
        StdOut.println("mean                    = " + ps.mean);
        StdOut.println("stddev                  = " + ps.stddev);
        StdOut.println("95% confidence interval = [" + ps.confidenceLo + ", " + ps.confidenceHi + ']');
    }
}
